var searchData=
[
  ['allocatepage',['allocatePage',['../classbadgerdb_1_1_file.html#a70243876aade6ca70ee0df940399c5a6',1,'badgerdb::File::allocatePage()'],['../classbadgerdb_1_1_page_file.html#ac52927298037f24bf77a35d875523237',1,'badgerdb::PageFile::allocatePage()'],['../classbadgerdb_1_1_blob_file.html#addb4966ed7ec465be69e4ce9f62453be',1,'badgerdb::BlobFile::allocatePage()']]],
  ['allocpage',['allocPage',['../classbadgerdb_1_1_buf_mgr.html#ab9ae3b12aac55b119b5763e3de2a4d2b',1,'badgerdb::BufMgr']]]
];
